## Packages
framer-motion | Smooth animations for result reveal and page transitions
clsx | Utility for conditional class names
tailwind-merge | Utility for merging tailwind classes

## Notes
API expects nested JSON structure for predictions.
Status endpoint available at /api/status.
